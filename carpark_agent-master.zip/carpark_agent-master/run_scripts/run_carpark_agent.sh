#!/bin/bash

cd /home/pi/Desktop/carpark_agent/carpark_aea
source ../venv/bin/activate
aea run